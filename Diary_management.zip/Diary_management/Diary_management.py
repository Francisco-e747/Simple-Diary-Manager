# -*- coding: utf-8 -*-
"""
Created on Thu Nov 21 16:41:45 2024

@author: HP
"""

import os


def write_diary():
    """
    Function to write a new diary entry.

    This function prompts the user for the date, title, and content of the diary entry.
    It then appends the entry in the specified format to the diary file.
    """
    date = input("Please enter the date (YYYY-MM-DD): ")
    title = input("Please enter the title of the diary: ")
    content = input("Please enter the content of the diary: ")

    # Format the diary entry
    entry = f"{date}|{title}|{content}\n"

    with open("diary.txt", "a") as f:
        f.write(entry)

    print("Diary entry successfully written!")


def view_diaries():
    """
    Function to view all diary entries.

    This function reads the diary file, parses each entry, and displays the date,
    title, and a short preview of the content for each entry.
    """
    if not os.path.exists("diary.txt"):
        print("No diary entries found.")
        return

    with open("diary.txt", "r") as f:
        entries = f.readlines()

    for entry in entries:
        date, title, content = entry.strip().split("|")
        print(f"Date: {date}")
        print(f"Title: {title}")
        print(f"Preview: {content[:50]}...\n")


def search_diaries():
    """
    Function to search for diary entries based on a keyword.

    This function prompts the user for a keyword and searches through the diary
    entries. If a match is found in the title or content, it displays the relevant entry.
    """
    keyword = input("Please enter the keyword to search for: ")

    if not os.path.exists("diary.txt"):
        print("No diary entries found.")
        return

    with open("diary.txt", "r") as f:
        entries = f.readlines()

    found_entries = []
    for entry in entries:
        date, title, content = entry.strip().split("|")
        if keyword in title or keyword in content:
            found_entries.append(entry)

    if found_entries:
        print(f"Found {len(found_entries)} entries matching the keyword:")
        for entry in found_entries:
            date, title, content = entry.strip().split("|")
            print(f"Date: {date}")
            print(f"Title: {title}")
            print(f"Preview: {content[:50]}...\n")
    else:
        print("No entries found matching the keyword.")


def delete_diary():
    """
    Function to delete a specific diary entry.

    This function prompts the user for the date and title of the entry to delete.
    It then reads the diary file, removes the matching entry, and rewrites the file
    without the deleted entry.
    """
    date_to_delete = input("Please enter the date (YYYY-MM-DD) of the entry to delete: ")
    title_to_delete = input("Please enter the title of the entry to delete: ")

    if not os.path.exists("diary.txt"):
        print("No diary entries found.")
        return

    with open("diary.txt", "r") as f:
        entries = f.readlines()

    new_entries = []
    for entry in entries:
        date, title, content = entry.strip().split("|")
        if not (date == date_to_delete and title == title_to_delete):
            new_entries.append(entry)

    with open("diary.txt", "w") as f:
        f.writelines(new_entries)

    print("Diary entry successfully deleted!")


if __name__ == "__main__":
    while True:
        print("Diary Management System")
        print("1. Write a new diary entry")
        print("2. View all diary entries")
        print("3. Search for diary entries")
        print("4. Delete a diary entry")
        print("5. Quit")

        choice = input("Please enter your choice (1-5): ")

        if choice == "1":
            write_diary()
        elif choice == "2":
            view_diaries()
        elif choice == "3":
            search_diaries()
        elif choice == "4":
            delete_diary()
        elif choice == "5":
            break
        else:
            print("Invalid choice. Please try again.")